# Texture credits

All textures are CC0 (public domain). Attribution is not required but given gladly.

| File | Source | Licence |
|---|---|---|
| `faceplate_painted_metal.jpg` | [Blue Metal Plate](https://polyhaven.com/a/blue_metal_plate), Poly Haven (diffuse, 2K) — desaturated and tinted to bone at runtime | CC0 |
| `wood_rosewood.jpg` | [Rosewood Veneer 1](https://polyhaven.com/a/rosewood_veneer1), Poly Haven (diffuse, 1K) | CC0 |
